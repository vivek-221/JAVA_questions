import java.util.Scanner;
class equal_nums
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num1:");
		int n1 = sc.nextInt();
		System.out.println("Enter num2:");
		int n2 = sc.nextInt();
		if(n1==n2)
		{
			System.out.println("equal");

		}
		else
		{
			System.out.println(" not equal");
		}
		
		
}
}