class A_grade_girls
{
	public static void main(String[] args) {
		
		int total_students=90;
		int boy_students=45;
		int total_A_grade_students=(int)(((float)50/100)*total_students);
		int boy_A_grade=20;
		int girl_A_grade = total_A_grade_students - boy_A_grade ;
		System.out.println(girl_A_grade);
		}
		}


